console.log("Hello World!");
console.warn("Warning...");
console.error("Fatal Error!!!");

document.write("Hello to JavaScript");
//alert("Hello World");
//prompt("Enter your name:");

//variables
var myName;
myName="Krystle";
var myAge=34;
var isStudent=true;
var children=3;
var partner="Ondra";
var live="Virginia";
var job="Analyst";
var email="krystle.monet@gmail.com";
var password="password";
var country="USA";
var salary= "1234";
var pet="yes";
var military="yes";
var service="Air Force"
var color="blue";
var hobby="woodwork";
var car="truck";
var degree="masters";
var movie="Harry Potter";
var sport="soccer";
var team="Cowboys";

//exercise #2
var myName="krystle";
var email="krystle.monet@gmail.com";
var password="password";
var age=34;
var country="USA";
var salary= "1234";

var newertemp=`
    <p> Name: ${myName}</p>
    <p> Email: ${email}</p>
    <p> Annual salary: ${salary*12}
    `

//var oldtmp="<p> Name: " + myName + "</p><p> Age: " + myAge + " </p> <p>Active: " + isStudent + "</P>";

var newtmp=`
    <p> Name: ${myName} </p>
    <p> Age: ${myAge} </P>
    <p> Active: ${isStudent} </p>
    <p> Children: ${children} </p>
    <p> Partner: ${partner} </p>
    <p> Live In: ${live} </p>
    <p> Job: ${job} </p>
    <p> Email: ${email} </p>
    <p> Annual salary: ${salary*12} </p>
    <p> Country: ${country} </p>
    <p> Password: ${password} </p>
    <p> Pet: ${pet} </p>
    <p> Military: ${military} </p>
    <p> Branch: ${service} </p>
    <p> Favorite Color: ${color} </p>
    <p> Favorite Hobby: ${hobby} </p>
    <p> Current Car: ${car} </p>
    <p> Highest Degree: ${degree} </p>
    <p> Favorite Movie: ${movie} </p>
    <p> Favorite Sporte: ${sport} </p>
    <p> Favorite Football Team: ${team} </p>
`;

document.write(newtmp);

const taxes=0.16;
console.log(2000*taxes);
let clientName="Jake";
console.log(clientName);
